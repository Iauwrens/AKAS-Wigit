<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Akas-wiget";

$conn = new mysqli($servername, $username, $password, $dbname);

if(!$conn){
    echo 'Connection error: ' . mysqli_connect_error() . "<br>";
}
else{
    echo 'Connection successful' . "<br>";
}

?>