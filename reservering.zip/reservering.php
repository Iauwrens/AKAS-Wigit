<?php

include("DB.php");

$personen = $_POST['personen'];
$datum = $_POST['datum'];
$tijd = $_POST['tijd'];
$naam = $_POST['naam'];
$email = $_POST['email'];

$sql = "INSERT INTO reservering (AantalPersonen, Datum, Tijd, Naam, Email)
VALUES ('$personen', '$datum', '$tijd', '$naam', '$email')";
    
if ($conn->query($sql) === TRUE) {
  $response = "New record created successfully";
} else {
  $response = "Error: " . $sql . "<br>" . $conn->error;
}
    
return $response;
$conn->close();

?>